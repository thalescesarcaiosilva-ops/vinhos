<?php
/**
 * Plugin Name: WooCommerce Checkout em Etapas
 * Description: Checkout em 3 etapas via shortcode, widget ou bloco — sem substituir o checkout do WooCommerce automaticamente.
 * Version: 1.3.0
 * Author: Luzitana
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 8.0
 * Text Domain: woocommerce-vinelle-checkout
 */

defined('ABSPATH') || exit;

define('VINELLE_CHECKOUT_VERSION', '1.3.0');
define('VINELLE_CHECKOUT_PATH', plugin_dir_path(__FILE__));
define('VINELLE_CHECKOUT_URL', plugin_dir_url(__FILE__));

require_once VINELLE_CHECKOUT_PATH . 'includes/class-vinelle-settings.php';
require_once VINELLE_CHECKOUT_PATH . 'includes/class-vinelle-shortcode.php';
require_once VINELLE_CHECKOUT_PATH . 'includes/class-vinelle-checkout.php';

if (is_admin()) {
    require_once VINELLE_CHECKOUT_PATH . 'includes/class-vinelle-admin.php';
}

require_once VINELLE_CHECKOUT_PATH . 'includes/class-vinelle-widget.php';
require_once VINELLE_CHECKOUT_PATH . 'includes/class-vinelle-block.php';

register_activation_hook(__FILE__, static function (): void {
    if (!get_option(Vinelle_Settings::OPTION_KEY)) {
        update_option(Vinelle_Settings::OPTION_KEY, Vinelle_Settings::defaults());
    }
});

add_action('plugins_loaded', static function (): void {
    Vinelle_Settings::init();

    if (is_admin() && class_exists('Vinelle_Admin')) {
        Vinelle_Admin::init();
    }

    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', static function (): void {
            if (!current_user_can('activate_plugins')) {
                return;
            }
            echo '<div class="notice notice-error"><p><strong>Checkout em Etapas</strong> requer o WooCommerce ativo.</p></div>';
        });
        return;
    }

    Vinelle_Shortcode::init();
    Vinelle_Widget::init();
    Vinelle_Block::init();
    Vinelle_Checkout::init();
}, 20);

add_action('before_woocommerce_init', static function (): void {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, false);
    }
});
