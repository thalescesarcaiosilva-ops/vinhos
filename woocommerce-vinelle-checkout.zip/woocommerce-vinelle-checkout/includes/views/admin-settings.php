<?php
defined('ABSPATH') || exit;

/** @var array $settings */
?>
<div class="wrap vinelle-admin-wrap">
    <h1><?php esc_html_e('Checkout em Etapas', 'woocommerce-vinelle-checkout'); ?></h1>
    <p class="description">
        <?php esc_html_e('Personalize o checkout em 3 passos. Desative para voltar ao checkout padrão do WooCommerce.', 'woocommerce-vinelle-checkout'); ?>
    </p>

    <?php if (Vinelle_Admin::is_block_checkout_active()) : ?>
        <div class="notice notice-warning inline">
            <p>
                <?php esc_html_e('Detectamos checkout em blocos na página de checkout. Este plugin usa o checkout clássico.', 'woocommerce-vinelle-checkout'); ?>
            </p>
        </div>
    <?php endif; ?>

        <div class="wcsc-admin-instructions">
            <h2><?php esc_html_e('Como usar na página de checkout', 'woocommerce-vinelle-checkout'); ?></h2>
            <ol>
                <li><?php esc_html_e('Edite a página de checkout do WooCommerce.', 'woocommerce-vinelle-checkout'); ?></li>
                <li><?php esc_html_e('Remova o bloco/shortcode [woocommerce_checkout] padrão.', 'woocommerce-vinelle-checkout'); ?></li>
                <li><?php esc_html_e('Adicione um destes:', 'woocommerce-vinelle-checkout'); ?>
                    <ul>
                        <li><?php esc_html_e('Bloco “Checkout em Etapas” (editor de blocos)', 'woocommerce-vinelle-checkout'); ?></li>
                        <li><?php esc_html_e('Bloco Shortcode com:', 'woocommerce-vinelle-checkout'); ?> <code>[wc_step_checkout]</code></li>
                        <li><?php esc_html_e('Widget “Checkout em Etapas (WooCommerce)” na área de widgets do tema', 'woocommerce-vinelle-checkout'); ?></li>
                    </ul>
                </li>
            </ol>
            <?php if (function_exists('wc_get_page_id')) : ?>
                <?php $checkout_id = wc_get_page_id('checkout'); ?>
                <?php if ($checkout_id > 0) : ?>
                    <p><a class="button button-secondary" href="<?php echo esc_url(get_edit_post_link($checkout_id)); ?>"><?php esc_html_e('Editar página de checkout', 'woocommerce-vinelle-checkout'); ?></a></p>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <form method="post" action="options.php" class="vinelle-admin-form">
        <?php settings_fields('vinelle_checkout_settings_group'); ?>

        <table class="form-table" role="presentation">
            <tr>
                <th scope="row"><?php esc_html_e('Modo de exibição', 'woocommerce-vinelle-checkout'); ?></th>
                <td>
                    <label><input type="radio" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[display_mode]" value="widget" <?php checked($settings['display_mode'], 'widget'); ?> /> <?php esc_html_e('Shortcode / Widget / Bloco (recomendado)', 'woocommerce-vinelle-checkout'); ?></label><br />
                    <label><input type="radio" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[display_mode]" value="replace" <?php checked($settings['display_mode'], 'replace'); ?> /> <?php esc_html_e('Substituir checkout WooCommerce automaticamente', 'woocommerce-vinelle-checkout'); ?></label>
                    <p class="description"><?php esc_html_e('No modo recomendado, o layout só aparece onde você inserir o shortcode ou widget.', 'woocommerce-vinelle-checkout'); ?></p>
                </td>
            </tr>

            <tr>
                <th scope="row"><?php esc_html_e('Checkout padrão', 'woocommerce-vinelle-checkout'); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[hide_default_checkout]" value="yes" <?php checked($settings['hide_default_checkout'], 'yes'); ?> />
                        <?php esc_html_e('Ocultar [woocommerce_checkout] quando o shortcode/bloco estiver na página', 'woocommerce-vinelle-checkout'); ?>
                    </label>
                </td>
            </tr>

            <tr>
                <th scope="row"><?php esc_html_e('Ativar layout', 'woocommerce-vinelle-checkout'); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[enabled]" value="yes" <?php checked($settings['enabled'], 'yes'); ?> />
                        <?php esc_html_e('Usar checkout em 3 etapas', 'woocommerce-vinelle-checkout'); ?>
                    </label>
                </td>
            </tr>

            <tr>
                <th scope="row"><?php esc_html_e('Barra superior do checkout', 'woocommerce-vinelle-checkout'); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[show_header_bar]" value="yes" <?php checked($settings['show_header_bar'], 'yes'); ?> />
                        <?php esc_html_e('Exibir barra com logo e link voltar (desligado se o tema já tem cabeçalho)', 'woocommerce-vinelle-checkout'); ?>
                    </label>
                </td>
            </tr>

            <tr>
                <th scope="row"><?php esc_html_e('Logo (URL)', 'woocommerce-vinelle-checkout'); ?></th>
                <td>
                    <div class="vinelle-media-row">
                        <input type="url" class="regular-text vinelle-logo-url" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[logo_url]" value="<?php echo esc_attr($settings['logo_url']); ?>" placeholder="https://..." />
                        <button type="button" class="button vinelle-upload-logo"><?php esc_html_e('Selecionar imagem', 'woocommerce-vinelle-checkout'); ?></button>
                    </div>
                    <p class="description"><?php esc_html_e('Deixe vazio para usar o logo do WordPress (Personalizar → Identidade do site).', 'woocommerce-vinelle-checkout'); ?></p>
                    <?php if (!empty($settings['logo_url'])) : ?>
                        <p><img src="<?php echo esc_url($settings['logo_url']); ?>" alt="" style="max-height:48px;margin-top:8px;" /></p>
                    <?php endif; ?>
                </td>
            </tr>

            <tr>
                <th scope="row"><?php esc_html_e('Link “Voltar”', 'woocommerce-vinelle-checkout'); ?></th>
                <td>
                    <input type="url" class="regular-text" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[back_url]" value="<?php echo esc_attr($settings['back_url']); ?>" placeholder="<?php echo esc_attr(home_url('/')); ?>" />
                    <p class="description"><?php esc_html_e('Deixe vazio para usar a página da loja WooCommerce.', 'woocommerce-vinelle-checkout'); ?></p>
                </td>
            </tr>

            <tr>
                <th scope="row"><?php esc_html_e('Título da página', 'woocommerce-vinelle-checkout'); ?></th>
                <td>
                    <input type="text" class="regular-text" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[page_title]" value="<?php echo esc_attr($settings['page_title']); ?>" />
                </td>
            </tr>

            <tr>
                <th scope="row"><?php esc_html_e('Subtítulo', 'woocommerce-vinelle-checkout'); ?></th>
                <td>
                    <textarea class="large-text" rows="2" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[page_subtitle]"><?php echo esc_textarea($settings['page_subtitle']); ?></textarea>
                </td>
            </tr>

            <tr>
                <th scope="row"><?php esc_html_e('Título do resumo', 'woocommerce-vinelle-checkout'); ?></th>
                <td>
                    <input type="text" class="regular-text" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[sidebar_title]" value="<?php echo esc_attr($settings['sidebar_title']); ?>" />
                </td>
            </tr>

            <tr>
                <th scope="row"><?php esc_html_e('Cores', 'woocommerce-vinelle-checkout'); ?></th>
                <td>
                    <label>
                        <?php esc_html_e('Cor de destaque (stepper, links)', 'woocommerce-vinelle-checkout'); ?>
                        <input type="text" class="vinelle-color-field" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[primary_color]" value="<?php echo esc_attr($settings['primary_color']); ?>" data-default-color="#2271b1" />
                    </label>
                    <br /><br />
                    <label>
                        <?php esc_html_e('Cor do botão finalizar', 'woocommerce-vinelle-checkout'); ?>
                        <input type="text" class="vinelle-color-field" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[buy_color]" value="<?php echo esc_attr($settings['buy_color']); ?>" data-default-color="#2e7d32" />
                    </label>
                </td>
            </tr>

            <tr>
                <th scope="row"><?php esc_html_e('Comportamento', 'woocommerce-vinelle-checkout'); ?></th>
                <td>
                    <label><input type="checkbox" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[hide_theme_header]" value="yes" <?php checked($settings['hide_theme_header'], 'yes'); ?> /> <?php esc_html_e('Ocultar título/breadcrumb do tema no checkout', 'woocommerce-vinelle-checkout'); ?></label><br />
                    <label><input type="checkbox" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[show_trust_badges]" value="yes" <?php checked($settings['show_trust_badges'], 'yes'); ?> /> <?php esc_html_e('Exibir selos de segurança (SSL, dados protegidos)', 'woocommerce-vinelle-checkout'); ?></label><br />
                    <label><input type="checkbox" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[cep_autofill]" value="yes" <?php checked($settings['cep_autofill'], 'yes'); ?> /> <?php esc_html_e('Preencher endereço automaticamente via CEP (ViaCEP)', 'woocommerce-vinelle-checkout'); ?></label>
                </td>
            </tr>

            <tr>
                <th scope="row"><?php esc_html_e('Banner Pix', 'woocommerce-vinelle-checkout'); ?></th>
                <td>
                    <label><input type="checkbox" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[pix_banner_enabled]" value="yes" <?php checked($settings['pix_banner_enabled'], 'yes'); ?> /> <?php esc_html_e('Mostrar banner de desconto Pix na etapa 1', 'woocommerce-vinelle-checkout'); ?></label>
                    <p>
                        <label>
                            <?php esc_html_e('Percentual exibido', 'woocommerce-vinelle-checkout'); ?>
                            <input type="number" min="0" max="100" step="1" class="small-text" name="<?php echo esc_attr(Vinelle_Settings::OPTION_KEY); ?>[pix_discount_percent]" value="<?php echo esc_attr($settings['pix_discount_percent']); ?>" /> %
                        </label>
                    </p>
                    <p class="description"><?php esc_html_e('Apenas informativo no layout. O desconto real deve ser configurado no gateway/cupom.', 'woocommerce-vinelle-checkout'); ?></p>
                </td>
            </tr>
        </table>

        <?php submit_button(__('Salvar configurações', 'woocommerce-vinelle-checkout')); ?>
    </form>
</div>
