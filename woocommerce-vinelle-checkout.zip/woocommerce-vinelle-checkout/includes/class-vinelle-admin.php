<?php
defined('ABSPATH') || exit;

class Vinelle_Admin {
    public static function init(): void {
        add_action('admin_menu', [self::class, 'register_menu']);
        add_action('admin_init', [self::class, 'register_settings']);
        add_action('admin_enqueue_scripts', [self::class, 'enqueue_assets']);
        add_filter('plugin_action_links_' . plugin_basename(VINELLE_CHECKOUT_PATH . 'woocommerce-vinelle-checkout.php'), [self::class, 'plugin_links']);
        add_action('admin_notices', [self::class, 'maybe_warn_blocks_checkout']);
    }

    public static function register_menu(): void {
        add_submenu_page(
            'woocommerce',
            __('Checkout em Etapas', 'woocommerce-vinelle-checkout'),
            __('Checkout em Etapas', 'woocommerce-vinelle-checkout'),
            'manage_woocommerce',
            'vinelle-checkout',
            [self::class, 'render_page']
        );
    }

    public static function register_settings(): void {
        register_setting(
            'vinelle_checkout_settings_group',
            Vinelle_Settings::OPTION_KEY,
            [
                'type'              => 'array',
                'sanitize_callback' => [Vinelle_Settings::class, 'sanitize'],
                'default'           => Vinelle_Settings::defaults(),
            ]
        );
    }

    public static function enqueue_assets(string $hook): void {
        if ($hook !== 'woocommerce_page_vinelle-checkout') {
            return;
        }

        wp_enqueue_style('wp-color-picker');
        wp_enqueue_media();

        wp_enqueue_style(
            'vinelle-checkout-admin',
            VINELLE_CHECKOUT_URL . 'assets/css/admin.css',
            [],
            VINELLE_CHECKOUT_VERSION
        );

        wp_enqueue_script(
            'vinelle-checkout-admin',
            VINELLE_CHECKOUT_URL . 'assets/js/admin.js',
            ['jquery', 'wp-color-picker'],
            VINELLE_CHECKOUT_VERSION,
            true
        );
    }

    public static function plugin_links(array $links): array {
        $url = admin_url('admin.php?page=vinelle-checkout');
        array_unshift(
            $links,
            '<a href="' . esc_url($url) . '">' . esc_html__('Configurações', 'woocommerce-vinelle-checkout') . '</a>'
        );
        return $links;
    }

    public static function maybe_warn_blocks_checkout(): void {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || !in_array($screen->id, ['woocommerce_page_vinelle-checkout', 'plugins'], true)) {
            return;
        }

        if (!Vinelle_Settings::is_yes('enabled')) {
            return;
        }

        if (self::is_block_checkout_active()) {
            echo '<div class="notice notice-warning"><p><strong>Checkout em Etapas:</strong> ';
            esc_html_e('O checkout em blocos do WooCommerce está ativo. Desative-o em WooCommerce → Configurações → Avançado para usar este layout.', 'woocommerce-vinelle-checkout');
            echo '</p></div>';
        }
    }

    public static function is_block_checkout_active(): bool {
        if (!function_exists('wc_get_page_id')) {
            return false;
        }

        $checkout_page_id = wc_get_page_id('checkout');
        if ($checkout_page_id <= 0) {
            return false;
        }

        return function_exists('has_block')
            && has_block('woocommerce/checkout', $checkout_page_id);
    }

    public static function render_page(): void {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Sem permissão.', 'woocommerce-vinelle-checkout'));
        }

        $settings = Vinelle_Settings::get_all();
        include VINELLE_CHECKOUT_PATH . 'includes/views/admin-settings.php';
    }
}
