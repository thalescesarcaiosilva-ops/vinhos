<?php
defined('ABSPATH') || exit;

class Vinelle_Checkout_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'wc_step_checkout_widget',
            __('Checkout em Etapas (WooCommerce)', 'woocommerce-vinelle-checkout'),
            [
                'description' => __('Exibe o checkout em 3 etapas. Use na página de checkout do WooCommerce.', 'woocommerce-vinelle-checkout'),
                'classname'   => 'wc-step-checkout-widget',
            ]
        );
    }

    public function widget($args, $instance): void {
        if (!Vinelle_Settings::is_yes('enabled')) {
            return;
        }

        echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

        if (!empty($instance['title'])) {
            echo $args['before_title'] . esc_html($instance['title']) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }

        echo do_shortcode('[' . Vinelle_Shortcode::TAG . ']');

        echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }

    public function form($instance): void {
        $title = $instance['title'] ?? '';
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Título (opcional):', 'woocommerce-vinelle-checkout'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p class="description">
            <?php esc_html_e('Recomendado: shortcode [wc_step_checkout] ou bloco no conteúdo da página. O widget funciona na área principal ou sidebar do checkout.', 'woocommerce-vinelle-checkout'); ?>
        </p>
        <?php
    }

    public function update($new_instance, $old_instance): array {
        return [
            'title' => sanitize_text_field($new_instance['title'] ?? ''),
        ];
    }
}

class Vinelle_Widget {
    public static function init(): void {
        add_action('widgets_init', static function (): void {
            register_widget('Vinelle_Checkout_Widget');
        });
    }
}
