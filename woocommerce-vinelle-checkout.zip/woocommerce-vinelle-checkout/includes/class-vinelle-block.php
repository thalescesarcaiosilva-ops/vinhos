<?php
defined('ABSPATH') || exit;

class Vinelle_Block {
    public static function init(): void {
        add_action('init', [self::class, 'register']);
    }

    public static function register(): void {
        if (!function_exists('register_block_type')) {
            return;
        }

        wp_register_script(
            'wc-step-checkout-block',
            VINELLE_CHECKOUT_URL . 'assets/js/block.js',
            ['wp-blocks', 'wp-element', 'wp-i18n'],
            VINELLE_CHECKOUT_VERSION,
            true
        );

        register_block_type('wc-step-checkout/form', [
            'api_version'     => 2,
            'editor_script'   => 'wc-step-checkout-block',
            'render_callback' => static function (): string {
                return do_shortcode('[' . Vinelle_Shortcode::TAG . ']');
            },
        ]);
    }
}
