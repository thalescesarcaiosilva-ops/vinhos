<?php
defined('ABSPATH') || exit;

class Vinelle_Shortcode {
    public const TAG = 'wc_step_checkout';

    public static function init(): void {
        add_shortcode(self::TAG, [self::class, 'render']);
    }

    public static function render($atts = [], $content = '', $tag = ''): string {
        if (!Vinelle_Settings::is_yes('enabled')) {
            return '<p class="wcsc-notice">' . esc_html__('Checkout em etapas desativado nas configurações.', 'woocommerce-vinelle-checkout') . '</p>';
        }

        if (!function_exists('is_checkout') || !is_checkout()) {
            return '<p class="wcsc-notice">' . esc_html__('Este checkout deve ser usado na página de checkout do WooCommerce.', 'woocommerce-vinelle-checkout') . '</p>';
        }

        if (function_exists('is_wc_endpoint_url') && is_wc_endpoint_url('order-received')) {
            return '';
        }

        Vinelle_Checkout::mark_embedded();

        ob_start();
        Vinelle_Checkout::render_checkout_form();
        return ob_get_clean();
    }

    public static function content_has_shortcode(?string $content): bool {
        if (!$content) {
            return false;
        }
        return has_shortcode($content, self::TAG) || strpos($content, '[' . self::TAG) !== false;
    }
}
