<?php
defined('ABSPATH') || exit;

class Vinelle_Settings {
    public const OPTION_KEY = 'vinelle_checkout_settings';

    public static function init(): void {
        // Opcional: defaults garantidos em runtime via get().
    }

    public static function defaults(): array {
        return [
            'display_mode'         => 'widget',
            'hide_default_checkout'=> 'yes',
            'enabled'              => 'yes',
            'logo_url'             => '',
            'back_url'             => '',
            'page_title'           => __('Finalizar compra', 'woocommerce-vinelle-checkout'),
            'page_subtitle'        => __('Complete as três etapas para concluir seu pedido.', 'woocommerce-vinelle-checkout'),
            'primary_color'        => '#2271b1',
            'buy_color'            => '#2e7d32',
            'show_header_bar'      => 'no',
            'hide_theme_header'    => 'no',
            'show_trust_badges'    => 'yes',
            'cep_autofill'         => 'yes',
            'pix_banner_enabled'   => 'no',
            'pix_discount_percent' => '10',
            'sidebar_title'        => __('Resumo do pedido', 'woocommerce-vinelle-checkout'),
        ];
    }

    public static function get_all(): array {
        $saved = get_option(self::OPTION_KEY, []);
        if (!is_array($saved)) {
            $saved = [];
        }
        return wp_parse_args($saved, self::defaults());
    }

    public static function get(string $key, $fallback = null) {
        $all = self::get_all();
        if (array_key_exists($key, $all)) {
            return $all[$key];
        }
        $defaults = self::defaults();
        if (array_key_exists($key, $defaults)) {
            return $defaults[$key];
        }
        return $fallback;
    }

    public static function is_yes(string $key): bool {
        return self::get($key, 'no') === 'yes';
    }

    public static function sanitize($input): array {
        if (!is_array($input)) {
            return self::defaults();
        }

        $defaults = self::defaults();
        $clean = [];

        $clean['enabled'] = isset($input['enabled']) && $input['enabled'] === 'yes' ? 'yes' : 'no';
        $mode = (string) ($input['display_mode'] ?? 'widget');
        $clean['display_mode'] = $mode === 'replace' ? 'replace' : 'widget';
        $clean['hide_default_checkout'] = isset($input['hide_default_checkout']) && $input['hide_default_checkout'] === 'yes' ? 'yes' : 'no';
        $clean['show_header_bar'] = isset($input['show_header_bar']) && $input['show_header_bar'] === 'yes' ? 'yes' : 'no';
        $clean['hide_theme_header'] = isset($input['hide_theme_header']) && $input['hide_theme_header'] === 'yes' ? 'yes' : 'no';
        $clean['show_trust_badges'] = isset($input['show_trust_badges']) && $input['show_trust_badges'] === 'yes' ? 'yes' : 'no';
        $clean['cep_autofill'] = isset($input['cep_autofill']) && $input['cep_autofill'] === 'yes' ? 'yes' : 'no';
        $clean['pix_banner_enabled'] = isset($input['pix_banner_enabled']) && $input['pix_banner_enabled'] === 'yes' ? 'yes' : 'no';

        $clean['logo_url'] = esc_url_raw(trim((string) ($input['logo_url'] ?? '')));
        $clean['back_url'] = esc_url_raw(trim((string) ($input['back_url'] ?? '')));

        $clean['page_title'] = sanitize_text_field((string) ($input['page_title'] ?? $defaults['page_title']));
        $clean['page_subtitle'] = sanitize_textarea_field((string) ($input['page_subtitle'] ?? $defaults['page_subtitle']));
        $clean['sidebar_title'] = sanitize_text_field((string) ($input['sidebar_title'] ?? $defaults['sidebar_title']));

        $primary = sanitize_hex_color((string) ($input['primary_color'] ?? $defaults['primary_color']));
        $buy = sanitize_hex_color((string) ($input['buy_color'] ?? $defaults['buy_color']));
        $clean['primary_color'] = $primary ?: $defaults['primary_color'];
        $clean['buy_color'] = $buy ?: $defaults['buy_color'];

        $pix_pct = absint($input['pix_discount_percent'] ?? $defaults['pix_discount_percent']);
        $clean['pix_discount_percent'] = (string) max(0, min(100, $pix_pct));

        return wp_parse_args($clean, $defaults);
    }
}
