<?php
defined('ABSPATH') || exit;

class Vinelle_Checkout {
    private static bool $embedded = false;

    private const STEP1_FIELDS = [
        'billing_first_name',
        'billing_last_name',
        'billing_email',
        'billing_phone',
    ];

    private const STEP2_FIELDS = [
        'billing_postcode',
        'billing_address_1',
        'billing_number',
        'billing_address_2',
        'billing_neighborhood',
        'billing_city',
        'billing_state',
        'billing_country',
    ];

    private const STEP3_FIELDS = [
        'billing_cpf',
    ];

    public static function init(): void {
        add_filter('woocommerce_locate_template', [self::class, 'locate_template'], 20, 3);
        add_filter('woocommerce_checkout_fields', [self::class, 'organize_fields'], 20);
        add_filter('body_class', [self::class, 'body_class']);
        add_filter('woocommerce_update_order_review_fragments', [self::class, 'shipping_fragment']);
        add_filter('woocommerce_update_order_review_fragments', [self::class, 'payment_fragment'], 25);
        add_filter('the_content', [self::class, 'filter_checkout_page_content'], 8);
        add_action('wp_enqueue_scripts', [self::class, 'enqueue_assets'], 99);
        add_action('template_redirect', [self::class, 'maybe_simplify_page'], 5);
        add_action('woocommerce_checkout_update_order_meta', [self::class, 'save_extra_fields']);
        add_filter('woocommerce_ship_to_different_address_checked', '__return_false');
        add_filter('woocommerce_checkout_posted_data', [self::class, 'mirror_billing_to_shipping']);
    }

    public static function mark_embedded(): void {
        self::$embedded = true;
    }

    public static function is_replace_mode(): bool {
        return Vinelle_Settings::get('display_mode', 'widget') === 'replace';
    }

    public static function page_uses_embedded_checkout(?WP_Post $post = null): bool {
        if (self::$embedded) {
            return true;
        }

        $post = $post ?: get_post();
        if (!$post instanceof WP_Post) {
            return false;
        }

        if (Vinelle_Shortcode::content_has_shortcode($post->post_content)) {
            return true;
        }

        if (has_block('wc-step-checkout/form', $post)) {
            return true;
        }

        return (bool) apply_filters('wc_step_checkout_page_has_embedded', false, $post);
    }

    public static function checkout_page_has_widget(): bool {
        if (!function_exists('is_checkout') || !is_checkout()) {
            return false;
        }

        $sidebars = wp_get_sidebars_widgets();
        if (!is_array($sidebars)) {
            return false;
        }

        foreach ($sidebars as $widgets) {
            if (!is_array($widgets)) {
                continue;
            }
            foreach ($widgets as $widget_id) {
                if (is_string($widget_id) && strpos($widget_id, 'wc_step_checkout_widget') === 0) {
                    return true;
                }
            }
        }

        return false;
    }

    public static function uses_embedded_output(): bool {
        return self::page_uses_embedded_checkout() || self::checkout_page_has_widget();
    }

    public static function checkout_page_has_embedded(?string $content = null): bool {
        if (self::$embedded) {
            return true;
        }

        if (Vinelle_Shortcode::content_has_shortcode($content)) {
            return true;
        }

        $post = get_post();
        if ($post instanceof WP_Post && has_block('wc-step-checkout/form', $post)) {
            return true;
        }

        return self::checkout_page_has_widget();
    }

    public static function is_enabled(): bool {
        if (!Vinelle_Settings::is_yes('enabled')) {
            return false;
        }
        if (!function_exists('is_checkout') || !is_checkout()) {
            return false;
        }
        if (function_exists('is_wc_endpoint_url') && is_wc_endpoint_url('order-received')) {
            return false;
        }

        if (self::is_replace_mode()) {
            return true;
        }

        return self::uses_embedded_output() || self::$embedded;
    }

    public static function filter_checkout_page_content(string $content): string {
        if (!Vinelle_Settings::is_yes('enabled') || !function_exists('is_checkout') || !is_checkout()) {
            return $content;
        }

        if (function_exists('is_wc_endpoint_url') && is_wc_endpoint_url('order-received')) {
            return $content;
        }

        if (self::is_replace_mode()) {
            return $content;
        }

        if (!self::checkout_page_has_embedded($content)) {
            return $content;
        }

        if (!Vinelle_Settings::is_yes('hide_default_checkout')) {
            return $content;
        }

        $content = preg_replace('/\[woocommerce_checkout[^\]]*\]/', '', $content) ?? $content;
        $content = preg_replace('/<!-- wp:woocommerce\/checkout\b.*?<!-- \/wp:woocommerce\/checkout -->/s', '', $content) ?? $content;

        return $content;
    }

    public static function render_checkout_form(): void {
        if (!function_exists('WC') || !WC()->checkout()) {
            echo '<p class="wcsc-notice">' . esc_html__('Checkout indisponível.', 'woocommerce-vinelle-checkout') . '</p>';
            return;
        }

        $checkout = WC()->checkout();
        $template = VINELLE_CHECKOUT_PATH . 'templates/checkout/form-checkout.php';

        if (!file_exists($template)) {
            echo '<p class="wcsc-notice">' . esc_html__('Template de checkout não encontrado.', 'woocommerce-vinelle-checkout') . '</p>';
            return;
        }

        include $template;
    }

    public static function render_review_order_sidebar(): void {
        $template = VINELLE_CHECKOUT_PATH . 'templates/checkout/review-order-sidebar.php';
        if (file_exists($template)) {
            include $template;
        }
    }

    /**
     * @return WC_Cart|null
     */
    public static function cart() {
        if (!function_exists('WC') || !WC()->cart) {
            return null;
        }
        return WC()->cart;
    }

    public static function locate_template(string $template, string $template_name, string $template_path): string {
        if (!self::is_enabled()) {
            return $template;
        }

        if (!self::is_replace_mode() && $template_name === 'checkout/form-checkout.php') {
            return $template;
        }

        $map = [
            'checkout/form-checkout.php'  => 'form-checkout.php',
            'checkout/review-order.php'   => 'review-order-sidebar.php',
        ];

        if (!isset($map[$template_name])) {
            return $template;
        }

        $plugin_template = VINELLE_CHECKOUT_PATH . 'templates/checkout/' . $map[$template_name];
        return file_exists($plugin_template) ? $plugin_template : $template;
    }

    public static function organize_fields(array $fields): array {
        if (!self::is_enabled()) {
            return $fields;
        }

        if (!isset($fields['billing'])) {
            return $fields;
        }

        $priorities = [
            'billing_first_name'      => 10,
            'billing_last_name'       => 20,
            'billing_email'           => 30,
            'billing_phone'           => 40,
            'billing_postcode'        => 50,
            'billing_address_1'       => 60,
            'billing_number'          => 65,
            'billing_address_2'       => 70,
            'billing_neighborhood'    => 75,
            'billing_city'            => 80,
            'billing_state'           => 90,
            'billing_country'         => 100,
            'billing_cpf'             => 110,
        ];

        foreach ($priorities as $key => $priority) {
            if (!isset($fields['billing'][$key])) {
                continue;
            }
            $fields['billing'][$key]['priority'] = $priority;
            $fields['billing'][$key]['class'] = array_values(array_unique(array_merge(
                $fields['billing'][$key]['class'] ?? ['form-row-wide'],
                ['vinelle-field']
            )));
        }

        if (isset($fields['billing']['billing_first_name'])) {
            $fields['billing']['billing_first_name']['label'] = __('Nome', 'woocommerce-vinelle-checkout');
            $fields['billing']['billing_first_name']['placeholder'] = __('Ex.: Maria', 'woocommerce-vinelle-checkout');
            $fields['billing']['billing_first_name']['class'] = ['form-row-first', 'vinelle-field'];
        }
        if (isset($fields['billing']['billing_last_name'])) {
            $fields['billing']['billing_last_name']['label'] = __('Sobrenome', 'woocommerce-vinelle-checkout');
            $fields['billing']['billing_last_name']['placeholder'] = __('Ex.: da Silva', 'woocommerce-vinelle-checkout');
            $fields['billing']['billing_last_name']['class'] = ['form-row-last', 'vinelle-field'];
        }
        if (isset($fields['billing']['billing_email'])) {
            $fields['billing']['billing_email']['placeholder'] = __('Ex.: maria@email.com', 'woocommerce-vinelle-checkout');
        }
        if (isset($fields['billing']['billing_phone'])) {
            $fields['billing']['billing_phone']['label'] = __('Celular / WhatsApp', 'woocommerce-vinelle-checkout');
            $fields['billing']['billing_phone']['placeholder'] = __('(11) 96123-4567', 'woocommerce-vinelle-checkout');
        }
        if (isset($fields['billing']['billing_postcode'])) {
            $fields['billing']['billing_postcode']['label'] = __('CEP', 'woocommerce-vinelle-checkout');
            $fields['billing']['billing_postcode']['placeholder'] = __('00000-000', 'woocommerce-vinelle-checkout');
            $fields['billing']['billing_postcode']['class'] = ['form-row-wide', 'vinelle-field', 'vinelle-cep-field'];
        }
        if (isset($fields['billing']['billing_address_1'])) {
            $fields['billing']['billing_address_1']['label'] = __('Rua', 'woocommerce-vinelle-checkout');
            $fields['billing']['billing_address_1']['placeholder'] = __('Rua, Avenida, etc.', 'woocommerce-vinelle-checkout');
        }
        if (isset($fields['billing']['billing_address_2'])) {
            $fields['billing']['billing_address_2']['label'] = __('Complemento', 'woocommerce-vinelle-checkout');
            $fields['billing']['billing_address_2']['required'] = false;
            $fields['billing']['billing_address_2']['placeholder'] = __('Apto, Bloco, etc.', 'woocommerce-vinelle-checkout');
            $fields['billing']['billing_address_2']['class'] = ['form-row-last', 'vinelle-field'];
        }
        if (isset($fields['billing']['billing_city'])) {
            $fields['billing']['billing_city']['label'] = __('Cidade', 'woocommerce-vinelle-checkout');
            $fields['billing']['billing_city']['class'] = ['form-row-first', 'vinelle-field'];
        }
        if (isset($fields['billing']['billing_state'])) {
            $fields['billing']['billing_state']['label'] = __('Estado', 'woocommerce-vinelle-checkout');
            $fields['billing']['billing_state']['class'] = ['form-row-last', 'vinelle-field'];
        }

        if (!isset($fields['billing']['billing_number'])) {
            $fields['billing']['billing_number'] = [
                'type'        => 'text',
                'label'       => __('Número', 'woocommerce-vinelle-checkout'),
                'required'    => true,
                'class'       => ['form-row-first', 'vinelle-field'],
                'priority'    => 65,
                'placeholder' => __('123', 'woocommerce-vinelle-checkout'),
            ];
        }

        if (!isset($fields['billing']['billing_neighborhood'])) {
            $fields['billing']['billing_neighborhood'] = [
                'type'        => 'text',
                'label'       => __('Bairro', 'woocommerce-vinelle-checkout'),
                'required'    => true,
                'class'       => ['form-row-wide', 'vinelle-field'],
                'priority'    => 75,
                'placeholder' => __('Seu bairro', 'woocommerce-vinelle-checkout'),
            ];
        }

        if (!isset($fields['billing']['billing_cpf'])) {
            $fields['billing']['billing_cpf'] = [
                'type'        => 'tel',
                'label'       => __('CPF', 'woocommerce-vinelle-checkout'),
                'required'    => true,
                'class'       => ['form-row-wide', 'vinelle-field', 'vinelle-cpf-field'],
                'priority'    => 110,
                'placeholder' => __('000.000.000-00', 'woocommerce-vinelle-checkout'),
                'custom_attributes' => [
                    'inputmode' => 'numeric',
                    'maxlength' => '14',
                ],
            ];
        } else {
            $fields['billing']['billing_cpf']['class'][] = 'vinelle-cpf-field';
        }

        return $fields;
    }

    public static function body_class(array $classes): array {
        if (!self::is_enabled()) {
            return $classes;
        }

        $classes[] = 'wc-step-checkout-active';

        if (Vinelle_Settings::is_yes('hide_theme_header')) {
            $classes[] = 'wc-step-checkout-hide-theme-header';
        }

        return $classes;
    }

    public static function shipping_fragment(array $fragments): array {
        if (!self::is_enabled()) {
            return $fragments;
        }

        ob_start();
        $cart = self::cart();
        echo '<div id="vinelle-shipping-methods" class="vinelle-shipping-methods">';
        if ($cart && $cart->needs_shipping() && $cart->show_shipping()) {
            wc_cart_totals_shipping_html();
        }
        echo '</div>';
        $fragments['#vinelle-shipping-methods'] = ob_get_clean();

        return $fragments;
    }

    public static function payment_fragment(array $fragments): array {
        if (!self::is_enabled() || !function_exists('woocommerce_checkout_payment')) {
            return $fragments;
        }

        ob_start();
        echo '<div id="order_review_payment" class="vinelle-payment-methods">';
        woocommerce_checkout_payment();
        echo '</div>';
        $fragments['#order_review_payment'] = ob_get_clean();

        return $fragments;
    }

    public static function save_extra_fields(int $order_id): void {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $map = [
            'billing_cpf'           => '_billing_cpf',
            'billing_number'        => '_billing_number',
            'billing_neighborhood'  => '_billing_neighborhood',
        ];

        foreach ($map as $post_key => $meta_key) {
            if (empty($_POST[$post_key])) {
                continue;
            }
            $value = 'billing_cpf' === $post_key
                ? preg_replace('/\D/', '', wp_unslash($_POST[$post_key]))
                : sanitize_text_field(wp_unslash($_POST[$post_key]));
            $order->update_meta_data($meta_key, $value);
        }

        $order->save();
    }

    public static function mirror_billing_to_shipping(array $data): array {
        if (!self::is_enabled()) {
            return $data;
        }

        foreach ($data as $key => $value) {
            if (strpos($key, 'billing_') !== 0) {
                continue;
            }
            $shipping_key = 'shipping_' . substr($key, 8);
            if (!isset($data[$shipping_key]) || $data[$shipping_key] === '') {
                $data[$shipping_key] = $value;
            }
        }

        return $data;
    }

    public static function enqueue_assets(): void {
        if (!self::is_enabled()) {
            return;
        }

        wp_enqueue_style(
            'vinelle-checkout',
            VINELLE_CHECKOUT_URL . 'assets/css/checkout.css',
            [],
            VINELLE_CHECKOUT_VERSION
        );

        $primary = sanitize_hex_color((string) Vinelle_Settings::get('primary_color'));
        $buy = sanitize_hex_color((string) Vinelle_Settings::get('buy_color'));
        if ($primary || $buy) {
            $css = '.vinelle-checkout-shell{';
            if ($primary) {
                $css .= '--wcsc-accent:' . $primary . ';--wcsc-primary:' . $primary . ';';
            }
            if ($buy) {
                $css .= '--wcsc-buy:' . $buy . ';';
            }
            $css .= '}';
            wp_add_inline_style('vinelle-checkout', $css);
        }

        wp_enqueue_script(
            'vinelle-checkout',
            VINELLE_CHECKOUT_URL . 'assets/js/checkout.js',
            ['jquery', 'wc-checkout'],
            VINELLE_CHECKOUT_VERSION,
            true
        );

        wp_localize_script('vinelle-checkout', 'vinelleCheckout', [
            'cepAutofill' => Vinelle_Settings::is_yes('cep_autofill'),
            'i18n' => [
                'step1Error' => __('Preencha nome, e-mail e telefone.', 'woocommerce-vinelle-checkout'),
                'step2Error' => __('Preencha o endereço completo.', 'woocommerce-vinelle-checkout'),
                'continueDelivery' => __('Continuar para Entrega', 'woocommerce-vinelle-checkout'),
                'continuePayment' => __('Continuar para Pagamento', 'woocommerce-vinelle-checkout'),
                'cepLoading' => __('Buscando endereço...', 'woocommerce-vinelle-checkout'),
                'cepError' => __('Não foi possível buscar o CEP.', 'woocommerce-vinelle-checkout'),
            ],
        ]);
    }

    public static function maybe_simplify_page(): void {
        if (!self::is_enabled()) {
            return;
        }

        add_filter('woocommerce_checkout_show_terms', '__return_true');
        add_filter('woocommerce_enable_order_notes_field', '__return_true');
    }

    public static function render_fields(WC_Checkout $checkout, array $keys, string $wrapper_class = ''): void {
        $fields = $checkout->get_checkout_fields('billing');
        echo $wrapper_class ? '<div class="' . esc_attr($wrapper_class) . '">' : '';
        foreach ($keys as $key) {
            if (!isset($fields[$key])) {
                continue;
            }
            woocommerce_form_field($key, $fields[$key], $checkout->get_value($key));
        }
        echo $wrapper_class ? '</div>' : '';
    }

    public static function get_logo_url(): string {
        $custom = trim((string) Vinelle_Settings::get('logo_url'));
        if ($custom !== '') {
            return apply_filters('vinelle_checkout_logo_url', esc_url($custom));
        }

        $custom_logo_id = get_theme_mod('custom_logo');
        if ($custom_logo_id) {
            $logo = wp_get_attachment_image_url($custom_logo_id, 'medium');
            if ($logo) {
                return apply_filters('vinelle_checkout_logo_url', $logo);
            }
        }

        return apply_filters('vinelle_checkout_logo_url', '');
    }

    public static function get_back_url(): string {
        $custom = trim((string) Vinelle_Settings::get('back_url'));
        if ($custom !== '') {
            return apply_filters('vinelle_checkout_back_url', esc_url($custom));
        }

        $shop = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : '';
        return apply_filters('vinelle_checkout_back_url', $shop ?: home_url('/'));
    }
}
