<?php
/**
 * Resumo do pedido — sidebar
 */

defined('ABSPATH') || exit;

$cart = Vinelle_Checkout::cart();
?>
<div class="vinelle-review-card">
    <div class="vinelle-review-card__body">
        <?php if (!$cart) : ?>
            <p><?php esc_html_e('Carrinho indisponível.', 'woocommerce-vinelle-checkout'); ?></p>
        <?php else : ?>
        <table class="shop_table woocommerce-checkout-review-order-table vinelle-review-table">
            <tbody>
                <?php
                foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
                    $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
                    if (!$_product || !$_product->exists() || $cart_item['quantity'] <= 0) {
                        continue;
                    }
                    $product_name = apply_filters('woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key);
                    $thumbnail = apply_filters('woocommerce_cart_item_thumbnail', $_product->get_image('thumbnail'), $cart_item, $cart_item_key);
                    ?>
                    <tr class="<?php echo esc_attr(apply_filters('woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key)); ?>">
                        <td class="vinelle-review-item">
                            <div class="vinelle-review-item__thumb"><?php echo $thumbnail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
                            <div class="vinelle-review-item__info">
                                <span class="vinelle-review-item__name"><?php echo wp_kses_post($product_name); ?></span>
                                <span class="vinelle-review-item__qty"><?php printf(esc_html__('Qtd: %s', 'woocommerce-vinelle-checkout'), esc_html((string) $cart_item['quantity'])); ?></span>
                            </div>
                        </td>
                        <td class="product-total vinelle-review-item__price">
                            <?php echo apply_filters('woocommerce_cart_item_subtotal', $cart->get_product_subtotal($_product, $cart_item['quantity']), $cart_item, $cart_item_key); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
            <tfoot>
                <tr class="cart-subtotal">
                    <th><?php esc_html_e('Subtotal', 'woocommerce'); ?></th>
                    <td><?php wc_cart_totals_subtotal_html(); ?></td>
                </tr>

                <?php foreach ($cart->get_coupons() as $code => $coupon) : ?>
                    <tr class="cart-discount coupon-<?php echo esc_attr(sanitize_title($code)); ?>">
                        <th><?php wc_cart_totals_coupon_label($coupon); ?></th>
                        <td><?php wc_cart_totals_coupon_html($coupon); ?></td>
                    </tr>
                <?php endforeach; ?>

                <?php if ($cart->needs_shipping() && $cart->show_shipping()) : ?>
                    <?php do_action('woocommerce_review_order_before_shipping'); ?>
                    <tr class="shipping vinelle-sidebar-shipping">
                        <th><?php esc_html_e('Frete', 'woocommerce-vinelle-checkout'); ?></th>
                        <td><?php wc_cart_totals_shipping_html(); ?></td>
                    </tr>
                    <?php do_action('woocommerce_review_order_after_shipping'); ?>
                <?php endif; ?>

                <?php foreach ($cart->get_fees() as $fee) : ?>
                    <tr class="fee">
                        <th><?php echo esc_html($fee->name); ?></th>
                        <td><?php wc_cart_totals_fee_html($fee); ?></td>
                    </tr>
                <?php endforeach; ?>

                <?php if (wc_tax_enabled() && !$cart->display_prices_including_tax()) : ?>
                    <?php if ('itemized' === get_option('woocommerce_tax_total_display')) : ?>
                        <?php foreach ($cart->get_tax_totals() as $code => $tax) : ?>
                            <tr class="tax-rate tax-rate-<?php echo esc_attr(sanitize_title($code)); ?>">
                                <th><?php echo esc_html($tax->label); ?></th>
                                <td><?php echo wp_kses_post($tax->formatted_amount); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr class="tax-total">
                            <th><?php echo esc_html(WC()->countries->tax_or_vat()); ?></th>
                            <td><?php wc_cart_totals_taxes_total_html(); ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endif; ?>

                <?php do_action('woocommerce_review_order_before_order_total'); ?>

                <tr class="order-total vinelle-order-total">
                    <th><?php esc_html_e('Total', 'woocommerce'); ?></th>
                    <td><?php wc_cart_totals_order_total_html(); ?></td>
                </tr>

                <?php do_action('woocommerce_review_order_after_order_total'); ?>
            </tfoot>
        </table>

        <?php if (wc_coupons_enabled()) : ?>
            <div class="vinelle-coupon">
                <label for="vinelle_coupon_code"><?php esc_html_e('Cupom de desconto', 'woocommerce-vinelle-checkout'); ?></label>
                <div class="vinelle-coupon__row">
                    <input type="text" name="coupon_code" class="input-text" id="vinelle_coupon_code" value="" placeholder="<?php esc_attr_e('Insira o código', 'woocommerce-vinelle-checkout'); ?>" />
                    <button type="submit" class="vinelle-btn vinelle-btn-muted" name="apply_coupon" value="<?php esc_attr_e('Apply coupon', 'woocommerce'); ?>">
                        <?php esc_html_e('Aplicar', 'woocommerce-vinelle-checkout'); ?>
                    </button>
                </div>
            </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
