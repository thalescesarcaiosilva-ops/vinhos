<?php
/**
 * Checkout Vinelle — 3 etapas
 *
 * @var WC_Checkout $checkout
 */

defined('ABSPATH') || exit;

do_action('woocommerce_before_checkout_form', $checkout);

if (!$checkout->is_registration_enabled() && $checkout->is_registration_required() && !is_user_logged_in()) {
    echo esc_html(apply_filters('woocommerce_checkout_must_be_logged_in_message', __('You must be logged in to checkout.', 'woocommerce')));
    return;
}

$logo_url = Vinelle_Checkout::get_logo_url();
$back_url = Vinelle_Checkout::get_back_url();
$page_title = (string) Vinelle_Settings::get('page_title');
$page_subtitle = (string) Vinelle_Settings::get('page_subtitle');
$show_pix_banner = Vinelle_Settings::is_yes('pix_banner_enabled');
$pix_discount = absint(Vinelle_Settings::get('pix_discount_percent'));
$show_trust = Vinelle_Settings::is_yes('show_trust_badges');
$show_header_bar = Vinelle_Settings::is_yes('show_header_bar');
$sidebar_title = (string) Vinelle_Settings::get('sidebar_title');
?>

<div class="vinelle-checkout-shell">
    <?php if ($show_header_bar) : ?>
    <header class="vinelle-checkout-topbar">
        <div class="vinelle-checkout-topbar__inner">
            <a href="<?php echo esc_url($back_url); ?>" class="vinelle-checkout-back">
                <span aria-hidden="true">←</span>
                <?php esc_html_e('Voltar', 'woocommerce-vinelle-checkout'); ?>
            </a>
            <?php if ($logo_url) : ?>
                <a href="<?php echo esc_url(home_url('/')); ?>" class="vinelle-checkout-logo">
                    <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" />
                </a>
            <?php else : ?>
                <span class="vinelle-checkout-brand"><?php echo esc_html(get_bloginfo('name')); ?></span>
            <?php endif; ?>
            <span class="vinelle-checkout-topbar__spacer" aria-hidden="true"></span>
        </div>
    </header>
    <?php endif; ?>

    <div class="vinelle-checkout-container">
        <div class="vinelle-checkout-heading">
            <h1><?php echo esc_html($page_title); ?></h1>
            <?php if ($page_subtitle !== '') : ?>
                <p><?php echo esc_html($page_subtitle); ?></p>
            <?php endif; ?>
        </div>

        <nav class="vinelle-stepper" aria-label="<?php esc_attr_e('Etapas do checkout', 'woocommerce-vinelle-checkout'); ?>">
            <ol>
                <li class="is-active" data-step-nav="1">
                    <button type="button" class="vinelle-stepper__btn" data-go-step="1">
                        <span class="vinelle-stepper__num">1</span>
                        <span class="vinelle-stepper__label"><?php esc_html_e('Identificação', 'woocommerce-vinelle-checkout'); ?></span>
                    </button>
                </li>
                <li data-step-nav="2">
                    <button type="button" class="vinelle-stepper__btn" data-go-step="2" disabled>
                        <span class="vinelle-stepper__num">2</span>
                        <span class="vinelle-stepper__label"><?php esc_html_e('Entrega', 'woocommerce-vinelle-checkout'); ?></span>
                    </button>
                </li>
                <li data-step-nav="3">
                    <button type="button" class="vinelle-stepper__btn" data-go-step="3" disabled>
                        <span class="vinelle-stepper__num">3</span>
                        <span class="vinelle-stepper__label"><?php esc_html_e('Pagamento', 'woocommerce-vinelle-checkout'); ?></span>
                    </button>
                </li>
            </ol>
        </nav>

        <form name="checkout" method="post" class="checkout woocommerce-checkout vinelle-checkout-form" action="<?php echo esc_url(wc_get_checkout_url()); ?>" enctype="multipart/form-data" aria-label="<?php echo esc_attr__('Checkout', 'woocommerce'); ?>">
            <?php if ($checkout->get_checkout_fields()) : ?>
                <?php do_action('woocommerce_checkout_before_customer_details'); ?>

                <div class="vinelle-checkout-grid">
                    <div class="vinelle-checkout-main">
                        <section class="vinelle-step-card is-active" data-step="1">
                            <header class="vinelle-step-card__head">
                                <span class="vinelle-step-card__badge">1</span>
                                <div>
                                    <h2><?php esc_html_e('Identificação', 'woocommerce-vinelle-checkout'); ?></h2>
                                    <p><?php esc_html_e('Preencha seus dados para envio do pedido.', 'woocommerce-vinelle-checkout'); ?></p>
                                </div>
                            </header>
                            <div class="vinelle-step-card__body">
                                <div class="woocommerce-billing-fields">
                                    <?php
                                    Vinelle_Checkout::render_fields($checkout, [
                                        'billing_first_name',
                                        'billing_last_name',
                                        'billing_email',
                                        'billing_phone',
                                    ], 'vinelle-fields-row');
                                    ?>
                                </div>
                                <?php if ($show_pix_banner && $pix_discount > 0) : ?>
                                    <div class="vinelle-pix-banner">
                                        <?php
                                        echo wp_kses(
                                            sprintf(
                                                __('Você ganha <strong>%s%% de desconto</strong> pagando com Pix', 'woocommerce-vinelle-checkout'),
                                                esc_html((string) $pix_discount)
                                            ),
                                            ['strong' => []]
                                        );
                                        ?>
                                    </div>
                                <?php endif; ?>
                                <button type="button" class="vinelle-btn vinelle-btn-primary" data-next-step="2">
                                    <?php esc_html_e('Continuar para Entrega', 'woocommerce-vinelle-checkout'); ?>
                                </button>
                            </div>
                        </section>

                        <section class="vinelle-step-card" data-step="2">
                            <header class="vinelle-step-card__head">
                                <span class="vinelle-step-card__badge">2</span>
                                <div>
                                    <h2><?php esc_html_e('Entrega', 'woocommerce-vinelle-checkout'); ?></h2>
                                    <p><?php esc_html_e('Informe o endereço de entrega.', 'woocommerce-vinelle-checkout'); ?></p>
                                </div>
                                <button type="button" class="vinelle-step-edit" data-go-step="1"><?php esc_html_e('Editar', 'woocommerce-vinelle-checkout'); ?></button>
                            </header>
                            <div class="vinelle-step-card__body">
                                <div class="woocommerce-billing-fields">
                                    <?php
                                    Vinelle_Checkout::render_fields($checkout, [
                                        'billing_postcode',
                                        'billing_address_1',
                                        'billing_number',
                                        'billing_address_2',
                                        'billing_neighborhood',
                                        'billing_city',
                                        'billing_state',
                                    ], 'vinelle-fields-row');
                                    ?>
                                    <?php
                                    if (isset($checkout->get_checkout_fields('billing')['billing_country'])) {
                                        woocommerce_form_field(
                                            'billing_country',
                                            $checkout->get_checkout_fields('billing')['billing_country'],
                                            $checkout->get_value('billing_country')
                                        );
                                    }
                                    ?>
                                </div>

                                <div class="vinelle-shipping-block">
                                    <p class="vinelle-shipping-block__title"><?php esc_html_e('Forma de entrega', 'woocommerce-vinelle-checkout'); ?></p>
                                    <div id="vinelle-shipping-methods" class="vinelle-shipping-methods">
                                        <?php
                                        $cart = Vinelle_Checkout::cart();
                                        if ($cart && $cart->needs_shipping() && $cart->show_shipping()) {
                                            wc_cart_totals_shipping_html();
                                        }
                                        ?>
                                    </div>
                                </div>

                                <button type="button" class="vinelle-btn vinelle-btn-primary" data-next-step="3">
                                    <?php esc_html_e('Continuar para Pagamento', 'woocommerce-vinelle-checkout'); ?>
                                </button>
                                <p class="vinelle-step-note">
                                    <?php esc_html_e('Confira atentamente seus dados — o endereço de entrega não pode ser alterado após o envio do pedido.', 'woocommerce-vinelle-checkout'); ?>
                                </p>
                            </div>
                        </section>

                        <section class="vinelle-step-card" data-step="3">
                            <header class="vinelle-step-card__head">
                                <span class="vinelle-step-card__badge">3</span>
                                <div>
                                    <h2><?php esc_html_e('Pagamento', 'woocommerce-vinelle-checkout'); ?></h2>
                                    <p><?php esc_html_e('Escolha uma forma de pagamento para finalizar.', 'woocommerce-vinelle-checkout'); ?></p>
                                </div>
                                <button type="button" class="vinelle-step-edit" data-go-step="2"><?php esc_html_e('Editar', 'woocommerce-vinelle-checkout'); ?></button>
                            </header>
                            <div class="vinelle-step-card__body">
                                <div class="vinelle-payment-doc">
                                    <?php Vinelle_Checkout::render_fields($checkout, ['billing_cpf']); ?>
                                </div>

                                <div id="order_review_payment" class="vinelle-payment-methods">
                                    <?php woocommerce_checkout_payment(); ?>
                                </div>
                            </div>
                        </section>

                        <?php if ($show_trust) : ?>
                        <div class="vinelle-trust">
                            <span><?php esc_html_e('Conexão segura SSL', 'woocommerce-vinelle-checkout'); ?></span>
                            <span><?php esc_html_e('Dados protegidos', 'woocommerce-vinelle-checkout'); ?></span>
                            <span><?php esc_html_e('Pagamento criptografado', 'woocommerce-vinelle-checkout'); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>

                    <aside class="vinelle-checkout-sidebar">
                        <h3 class="vinelle-sidebar-title"><?php echo esc_html($sidebar_title); ?></h3>
                        <div id="order_review" class="woocommerce-checkout-review-order vinelle-order-review">
                            <?php do_action('woocommerce_checkout_before_order_review'); ?>
                            <?php woocommerce_order_review(); ?>
                            <?php do_action('woocommerce_checkout_after_order_review'); ?>
                        </div>
                    </aside>
                </div>

                <?php do_action('woocommerce_checkout_after_customer_details'); ?>
            <?php endif; ?>
        </form>
    </div>
</div>

<?php do_action('woocommerce_after_checkout_form', $checkout); ?>
