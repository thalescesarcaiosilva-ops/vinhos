=== WooCommerce Checkout em Etapas ===
Stable tag: 1.3.0

Checkout em 3 etapas via shortcode, widget ou bloco Gutenberg — sem substituir o checkout WooCommerce automaticamente.

== Instalação ==

1. Envie `woocommerce-vinelle-checkout` para `/wp-content/plugins/`.
2. Ative o plugin.
3. Configure em **WooCommerce → Checkout em Etapas**.
4. Edite a página de checkout e adicione `[wc_step_checkout]`, o bloco ou o widget.
5. Remova o checkout padrão `[woocommerce_checkout]` (ou marque "Ocultar checkout padrão" nas configurações).

== Modos ==

* **Shortcode / Widget / Bloco (padrão):** layout só onde você inserir.
* **Substituir automaticamente:** comportamento antigo (troca templates WC).

== Segurança ==

* Settings API com sanitização
* Permissão `manage_woocommerce`
* Desativar layout volta ao checkout nativo sem quebrar o site
