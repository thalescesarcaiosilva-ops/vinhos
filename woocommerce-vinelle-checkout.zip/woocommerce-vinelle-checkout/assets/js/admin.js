(function ($) {
  'use strict';

  $(function () {
    if ($.fn.wpColorPicker) {
      $('.vinelle-color-field').wpColorPicker();
    }

    var frame;
    $(document.body).on('click', '.vinelle-upload-logo', function (e) {
      e.preventDefault();
      var $input = $('.vinelle-logo-url');

      if (frame) {
        frame.open();
        return;
      }

      frame = wp.media({
        title: 'Selecionar logo',
        button: { text: 'Usar esta imagem' },
        multiple: false,
      });

      frame.on('select', function () {
        var attachment = frame.state().get('selection').first().toJSON();
        if (attachment && attachment.url) {
          $input.val(attachment.url).trigger('change');
        }
      });

      frame.open();
    });
  });
})(jQuery);
