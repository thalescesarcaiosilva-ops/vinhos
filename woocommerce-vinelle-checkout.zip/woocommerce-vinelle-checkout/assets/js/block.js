(function (blocks, element, i18n) {
  var el = element.createElement;
  var __ = i18n.__;

  blocks.registerBlockType('wc-step-checkout/form', {
    title: __('Checkout em Etapas', 'woocommerce-vinelle-checkout'),
    icon: 'cart',
    category: 'widgets',
    description: __('Checkout WooCommerce em 3 etapas.', 'woocommerce-vinelle-checkout'),
    supports: {
      html: false,
      multiple: false,
    },
    edit: function () {
      return el(
        'div',
        { className: 'wc-step-checkout-block-editor' },
        el('strong', null, __('Checkout em Etapas (WooCommerce)', 'woocommerce-vinelle-checkout')),
        el('p', null, __('Substitua o bloco checkout padrão por este na página de checkout.', 'woocommerce-vinelle-checkout'))
      );
    },
    save: function () {
      return null;
    },
  });
})(window.wp.blocks, window.wp.element, window.wp.i18n);
