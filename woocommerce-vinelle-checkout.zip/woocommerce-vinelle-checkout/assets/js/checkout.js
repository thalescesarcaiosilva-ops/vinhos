(function ($) {
  'use strict';

  var cfg = window.vinelleCheckout || { i18n: {} };
  var currentStep = 1;

  function onlyDigits(value) {
    return String(value || '').replace(/\D/g, '');
  }

  function maskPhone(value) {
    var d = onlyDigits(value).slice(0, 11);
    if (d.length <= 10) {
      return d.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3').trim();
    }
    return d.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3').trim();
  }

  function maskCpf(value) {
    var d = onlyDigits(value).slice(0, 11);
    return d
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  }

  function maskCep(value) {
    return onlyDigits(value).slice(0, 8).replace(/(\d{5})(\d)/, '$1-$2');
  }

  function getField(id) {
    return document.getElementById(id);
  }

  function fieldValue(id) {
    var el = getField(id);
    return el ? String(el.value || '').trim() : '';
  }

  function validateStep1() {
    var first = fieldValue('billing_first_name');
    var last = fieldValue('billing_last_name');
    var email = fieldValue('billing_email');
    var phone = onlyDigits(fieldValue('billing_phone'));
    return !!(first && last && /\S+@\S+\.\S+/.test(email) && phone.length >= 10);
  }

  function validateStep2() {
    if (!validateStep1()) return false;
    return !!(
      fieldValue('billing_postcode') &&
      fieldValue('billing_address_1') &&
      fieldValue('billing_number') &&
      fieldValue('billing_neighborhood') &&
      fieldValue('billing_city') &&
      fieldValue('billing_state')
    );
  }

  function setStep(step) {
    currentStep = step;

    $('[data-step]').each(function () {
      var elStep = parseInt($(this).attr('data-step'), 10);
      $(this).toggleClass('is-active', elStep === step);
    });

    $('[data-step-nav]').each(function () {
      var navStep = parseInt($(this).attr('data-step-nav'), 10);
      $(this).toggleClass('is-active', navStep === step);
      $(this).toggleClass('is-done', navStep < step);
      $(this).find('.vinelle-stepper__btn').prop('disabled', navStep > step && (navStep === 2 ? !validateStep1() : !validateStep2()));
    });

    if (step >= 2) {
      $('[data-step-nav="2"] .vinelle-stepper__btn').prop('disabled', !validateStep1());
    }
    if (step >= 3) {
      $('[data-step-nav="3"] .vinelle-stepper__btn').prop('disabled', !validateStep2());
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function bindMasks() {
    $(document.body).on('input', '#billing_phone', function () {
      this.value = maskPhone(this.value);
    });
    $(document.body).on('input', '#billing_cpf', function () {
      this.value = maskCpf(this.value);
    });
    $(document.body).on('input', '#billing_postcode', function () {
      this.value = maskCep(this.value);
    });
  }

  function bindStepNav() {
    $(document.body).on('click', '[data-next-step]', function () {
      var next = parseInt($(this).attr('data-next-step'), 10);
      if (next === 2 && !validateStep1()) {
        window.alert(cfg.i18n.step1Error || 'Preencha nome, e-mail e telefone.');
        return;
      }
      if (next === 3 && !validateStep2()) {
        window.alert(cfg.i18n.step2Error || 'Preencha o endereço completo.');
        return;
      }
      setStep(next);
      if (next >= 2) {
        $(document.body).trigger('update_checkout');
      }
    });

    $(document.body).on('click', '[data-go-step]', function () {
      var step = parseInt($(this).attr('data-go-step'), 10);
      if (step === 2 && !validateStep1()) return;
      if (step === 3 && !validateStep2()) return;
      setStep(step);
    });
  }

  function bindCepLookup() {
    if (!cfg.cepAutofill) {
      return;
    }

    $(document.body).on('blur', '#billing_postcode', function () {
      var cep = onlyDigits(this.value);
      if (cep.length !== 8) return;

      var $field = $(this).closest('.form-row');
      var $loading = $field.find('.vinelle-cep-loading');
      if (!$loading.length) {
        $loading = $('<span class="vinelle-cep-loading"></span>').appendTo($field);
      }
      $loading.text(cfg.i18n.cepLoading || 'Buscando endereço...');

      fetch('https://viacep.com.br/ws/' + cep + '/json/')
        .then(function (res) {
          return res.json();
        })
        .then(function (data) {
          if (data.erro) {
            throw new Error('CEP not found');
          }
          if (data.logradouro) $('#billing_address_1').val(data.logradouro);
          if (data.bairro) $('#billing_neighborhood').val(data.bairro);
          if (data.localidade) $('#billing_city').val(data.localidade);
          if (data.uf) $('#billing_state').val(data.uf).trigger('change');
          $(document.body).trigger('update_checkout');
        })
        .catch(function () {
          window.alert(cfg.i18n.cepError || 'Não foi possível buscar o CEP.');
        })
        .finally(function () {
          $loading.text('');
        });
    });
  }

  function bindCheckoutErrors() {
    $(document.body).on('checkout_error', function () {
      setStep(3);
    });
  }

  $(function () {
    if (!$('form.vinelle-checkout-form').length) return;

    bindMasks();
    bindStepNav();
    bindCepLookup();
    bindCheckoutErrors();
    setStep(1);

    $('#vinelle_coupon_code').attr('name', 'coupon_code');
  });
})(jQuery);
